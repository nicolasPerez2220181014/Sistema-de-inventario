package com.terra.GestionYVentas.Models;

import lombok.Builder;
import java.io.Serializable;
import javax.persistence.*;
import lombok.Data;
import lombok.AllArgsConstructor;
/**
 * The persistent class for the users database table.
 * 
 */
@Builder
@AllArgsConstructor
@Data
@Entity
@Table(name="users")
@NamedQuery(name="User.findAll", query="SELECT u FROM User u")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_nick_name")
	private String userNickName;

	@Column(name="user_password")
	private String userPassword;

	@Column(name="fk_person_id")
	private Integer personId;

	@Column(name="fk_state_id")
	private Integer stateId;
	//bi-directional many-to-one association to Person
	@ManyToOne
	@JoinColumn(name="fk_person_id", updatable = false,insertable = false)
	private Person person;

	//bi-directional many-to-one association to State
	@ManyToOne
	@JoinColumn(name="fk_state_id", updatable = false,insertable = false)
	private State state;

	public User() {
	}

	public String getUserNickName() {
		return this.userNickName;
	}

	public void setUserNickName(String userNickName) {
		this.userNickName = userNickName;
	}

	public String getUserPassword() {
		return this.userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public Person getPerson() {
		return this.person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public State getState() {
		return this.state;
	}

	public void setState(State state) {
		this.state = state;
	}

}