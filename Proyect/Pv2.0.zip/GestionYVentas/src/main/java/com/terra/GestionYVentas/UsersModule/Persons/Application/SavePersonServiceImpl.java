package com.terra.GestionYVentas.UsersModule.Persons.Application;

import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Repository.PersonSaveRepository;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SavePersonService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@AllArgsConstructor
@Service
public class SavePersonServiceImpl implements SavePersonService {


    private final PersonSaveRepository repo;

    @Override
    public Integer savePerson(PersonDTO person) {
        return repo.savePerson(person);
    }
}
