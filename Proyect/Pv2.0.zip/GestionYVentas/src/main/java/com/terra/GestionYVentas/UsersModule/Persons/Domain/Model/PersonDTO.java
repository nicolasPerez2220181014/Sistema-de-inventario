package com.terra.GestionYVentas.UsersModule.Persons.Domain.Model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@Builder
@AllArgsConstructor
@Getter
public class PersonDTO {

    private Integer personId;

    private Date personBirthdate;

    private String personCellphone;

    private Date personCreationDate;

    private String personEmail;

    private String personIdentification;

    private String personLastname;

    private String personName;

    // Relations

    private Integer identificationId;

    private Integer roleId;

    private Integer cityId;



}
