package com.terra.GestionYVentas.UsersModule.Persons.Domain.Repository;

import com.terra.GestionYVentas.Models.Person;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;

public interface PersonSaveRepository {

    Integer savePerson(PersonDTO person);

}
