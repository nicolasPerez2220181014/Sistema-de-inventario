package com.terra.GestionYVentas.UsersModule.Persons.Infraestructure.Controllers;


import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SavePersonService;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SearchPersonService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.http.HttpHeaders;


@AllArgsConstructor
@RestController
@RequestMapping("/Api/v1/Person")
public class PersonController {

    //private final SavePersonService savePersonService;
    //private final SearchPersonService searchPersonService;


    @PutMapping ("/{id}")
    public ResponseEntity<HttpHeaders> SavePerson(@RequestBody PersonDTO person, @PathVariable("id") Integer id ){
        HttpStatus status = HttpStatus.NO_CONTENT;
        Integer loc = -1;
        //if (searchPersonService.searchPerson(id).isEmpty()){
        //    loc = savePersonService.savePerson(person);
        //    status= HttpStatus.CREATED;
        //}
        org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
        headers.add("Location", "/Api/v1/User/"+loc);
        return new ResponseEntity(headers, status);
    }

}
