package com.terra.GestionYVentas.UsersModule.Persons.Infraestructure.RepositoryJpa;

import com.terra.GestionYVentas.Models.Person;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Repository.PersonSearchRepository;
import com.terra.GestionYVentas.UsersModule.Persons.Infraestructure.Mapper.PersonMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@AllArgsConstructor
@Repository
public class PersonSearchRepositoryImpl implements PersonSearchRepository {

    private final JpaPerson jpaPerson;
    private final PersonMapper personMapper;

    @Override
    public Optional<PersonDTO> searchPerson(Integer id) {
        Optional<Person> response = jpaPerson.findById(id);
        if(response.isEmpty()) {
            return Optional.empty();
        }
        return  Optional.ofNullable(personMapper.personToPersonDTO(response.get()));
    }
}
