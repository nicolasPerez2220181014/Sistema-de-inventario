package com.terra.GestionYVentas.UsersModule.States.Infraestructure;

import com.terra.GestionYVentas.Models.State;
import com.terra.GestionYVentas.UsersModule.States.Domain.StateDTO;
import org.mapstruct.Mapper;


@Mapper
public class StateMapper {

    public StateDTO stateToStateDTO(State state){
        return StateDTO.builder().stateId(state.getStateId()).stateName(state.getStateName()).build();
    }

}
