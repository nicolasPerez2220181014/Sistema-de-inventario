package com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO;

import com.terra.GestionYVentas.Models.State;
import com.terra.GestionYVentas.UsersModule.States.Domain.StateDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;


import java.util.Date;

@Builder
@AllArgsConstructor
@Getter
public class UserDTO {
    private String userNickName;
    private String userPassword;
    private Integer stateId;
    private Integer personId;
}
