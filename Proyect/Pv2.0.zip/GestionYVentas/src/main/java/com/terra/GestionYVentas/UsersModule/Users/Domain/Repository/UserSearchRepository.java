package com.terra.GestionYVentas.UsersModule.Users.Domain.Repository;


import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;

import java.util.Optional;

public interface UserSearchRepository {

    Optional<UserDTO> search(String user);

}
