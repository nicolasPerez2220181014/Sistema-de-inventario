package com.terra.GestionYVentas.UsersModule.Users.Domain.Services;

import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;

public interface SaveUserService {

    String saveUser(UserDTO user);

}
