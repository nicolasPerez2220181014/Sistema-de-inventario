package com.terra.GestionYVentas.UsersModule.Users.Infraestructure.RepositoryJpa;

import com.terra.GestionYVentas.Models.User;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Repository.UserSearchRepository;
import com.terra.GestionYVentas.UsersModule.Users.Infraestructure.Mapper.UserMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@AllArgsConstructor
@Repository
public class UserSearchRepositoryImpl implements UserSearchRepository {

    private final JpaUser jpaUser;
    private final UserMapper userMapper;

    @Override
    public Optional<UserDTO> search(String user) {

        Optional<User> response = jpaUser.findById(user);
        if (response.isEmpty()){
            return Optional.ofNullable(null) ;
        }
        else{
            return Optional.ofNullable(userMapper.userToUserDTO(response.get()));
        }

    }
}