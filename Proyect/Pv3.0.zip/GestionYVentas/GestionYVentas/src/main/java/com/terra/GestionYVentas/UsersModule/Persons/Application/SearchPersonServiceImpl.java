package com.terra.GestionYVentas.UsersModule.Persons.Application;

import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SearchPersonService;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Repository.PersonSearchRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@AllArgsConstructor
public class SearchPersonServiceImpl implements SearchPersonService {

    private final PersonSearchRepository searchPersonRepository;


    @Override
    public Optional<PersonDTO> searchPerson(Integer id) {
        return searchPersonRepository.searchPerson(id);
    }
}
