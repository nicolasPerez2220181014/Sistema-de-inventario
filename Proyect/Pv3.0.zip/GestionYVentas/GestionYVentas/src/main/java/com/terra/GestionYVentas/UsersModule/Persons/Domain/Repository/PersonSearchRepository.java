package com.terra.GestionYVentas.UsersModule.Persons.Domain.Repository;

import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;

import java.util.Optional;

public interface PersonSearchRepository {

    Optional<PersonDTO> searchPerson(Integer id);
}
