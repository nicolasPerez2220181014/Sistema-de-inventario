package com.terra.GestionYVentas.UsersModule.Persons.Domain.Services;

import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;

public interface SavePersonService {

    Integer savePerson(PersonDTO person);

}
