package com.terra.GestionYVentas.UsersModule.Persons.Domain.Services;

import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;

import javax.swing.text.html.Option;
import java.util.Optional;

public interface SearchPersonService {

    Optional<PersonDTO> searchPerson(Integer id);

}
