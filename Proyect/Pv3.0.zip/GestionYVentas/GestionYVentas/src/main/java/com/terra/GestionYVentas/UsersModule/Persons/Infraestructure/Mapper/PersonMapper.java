package com.terra.GestionYVentas.UsersModule.Persons.Infraestructure.Mapper;

import com.terra.GestionYVentas.Models.Person;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import org.mapstruct.Mapper;

@Mapper
public abstract class PersonMapper {

        public PersonDTO personToPersonDTO(Person person){
            return PersonDTO.builder()
                    .personId(person.getPersonId())
                    .personBirthdate(person.getPersonBirthdate())
                    .personCellphone(person.getPersonCellphone())
                    .personCreationDate(person.getPersonCreationDate())
                    .personEmail(person.getPersonEmail())
                    .personName(person.getPersonName())
                    .personLastname(person.getPersonLastname())
                    .personIdentification(person.getPersonIdentification())
                    .cityId(person.getCityId())
                    .identificationId(person.getFkNamesIdentificationId())
                    .roleId(person.getRoleId()).build();
        }

        public Person personDTOToPerson(PersonDTO person){
            return Person.builder()
                    .personId(person.getPersonId())
                    .personBirthdate(person.getPersonBirthdate())
                    .personCellphone(person.getPersonCellphone())
                    .personEmail(person.getPersonEmail())
                    .personName(person.getPersonName())
                    .personLastname(person.getPersonLastname())
                    .personCreationDate(person.getPersonCreationDate())
                    .fkNamesIdentificationId(person.getIdentificationId())
                    .personIdentification(person.getPersonIdentification())
                    .roleId(person.getRoleId())
                    .cityId(person.getCityId())
                    .build();
        }

}