package com.terra.GestionYVentas.UsersModule.Persons.Infraestructure.RepositoryJpa;

import com.terra.GestionYVentas.Models.Person;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JpaPerson extends JpaRepository<Person, Integer> {
}
