package com.terra.GestionYVentas.UsersModule.Persons.Infraestructure.RepositoryJpa;

import com.terra.GestionYVentas.Models.Person;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Repository.PersonSaveRepository;
import com.terra.GestionYVentas.UsersModule.Persons.Infraestructure.Mapper.PersonMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

@AllArgsConstructor
@Repository
public class PersonSaveRepositoryImpl implements PersonSaveRepository{

    private final JpaPerson jpaPerson;
    private final PersonMapper personMapper;

    @Override
    public Integer savePerson(PersonDTO person) {
        return jpaPerson.save(personMapper.personDTOToPerson(person)).getPersonId();
    }
}
