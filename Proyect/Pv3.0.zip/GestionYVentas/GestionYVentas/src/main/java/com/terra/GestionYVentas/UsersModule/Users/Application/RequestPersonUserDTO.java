package com.terra.GestionYVentas.UsersModule.Users.Application;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.mapstruct.Builder;

import java.util.Date;

@AllArgsConstructor
@Data
public class RequestPersonUserDTO {
    //USER
    private String userNickName;
    private String userPassword;
    private Integer stateId;
    private Integer userPersonId;
    //PERSON
    private Integer personId;
    private Date personBirthdate;
    private String personCellphone;
    private Date personCreationDate;
    private String personEmail;
    private String personIdentification;
    private String personLastname;
    private String personName;
    //PersonRelations

    private Integer identificationId;

    private Integer roleId;

    private Integer cityId;

    /*
    *        /*[{
    "personId":1,
    "personBirthdate":"2001-11-06",
    "personCellphone": "3214755906",
    "personCreationDate":"2021-04-22",
    "personEmail":"Nicolle@gmail.com",
    "personIdentification":"123456789",
    "personLastname":"XAN DIAZ",
    "personName":"JEISSON TATIANA",
    "identificationId":1,
    "cityId":428,
    "roleId":1
},{
    "userNickName" : "NICOLLE",
    "userPassword":"PANDAS",
    "stateId":1,
    "personId":1
}]
        *
        * */
    *
    *
    * */
}
