package com.terra.GestionYVentas.UsersModule.Users.Application;

import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Repository.UserSearchRepository;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SearchUserService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@AllArgsConstructor
@Service
public class UserSearchServiceImpl implements SearchUserService {

    private final UserSearchRepository searchUser;

    @Override
    public Optional<UserDTO> SearchUser(String id) {
        return searchUser.search(id);
    }

//SearchUser.search(id).map(user -> UserDTO.builder()
//                .userNickName(id)
//                .userPassword(user.getUserPassword()).build())


}
