package com.terra.GestionYVentas.UsersModule.Users.Domain.Repository;

import com.terra.GestionYVentas.Models.User;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;

public interface UserSaveRepository {

    String saveService(UserDTO user);

}
