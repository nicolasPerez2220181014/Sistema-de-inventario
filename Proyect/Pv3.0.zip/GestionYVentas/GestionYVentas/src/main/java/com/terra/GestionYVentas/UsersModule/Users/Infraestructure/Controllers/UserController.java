package com.terra.GestionYVentas.UsersModule.Users.Infraestructure.Controllers;



import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SavePersonService;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SearchPersonService;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SaveUserService;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SearchUserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@AllArgsConstructor
@RestController
@RequestMapping("/Api/v1/User")
public class UserController {

    private final SearchUserService searchUserService;
    private final SaveUserService saveUserService;
    private final SavePersonService savePersonService;
    private final SearchPersonService searchPersonService;


    @PutMapping("/{id}")
    public ResponseEntity<HttpHeaders> addUser(@RequestBody RequestPersonUserDTO requestPersonUserDTO, @PathVariable("id") Integer id) {

        PersonDTO person = PersonDTO.builder().build();
        UserDTO user = UserDTO.builder().build();

        String loc = "USER_ALREADY_EXIST";
        HttpStatus status = HttpStatus.I_AM_A_TEAPOT;
        if (searchPersonService.searchPerson(id).isEmpty()) {
            loc = savePersonService.savePerson(person) + " Person_Saved";
            status = HttpStatus.CREATED;
        }

        if (searchUserService.SearchUser(user.getUserNickName()).isEmpty()) {
            loc += " and " + saveUserService.saveUser(user) + " Appended_To_Person";
        }
        HttpHeaders headers = new HttpHeaders();
        headers.add("Location", "/Api/v1/User/" + loc);
        return new ResponseEntity(headers, status);


    }
}


