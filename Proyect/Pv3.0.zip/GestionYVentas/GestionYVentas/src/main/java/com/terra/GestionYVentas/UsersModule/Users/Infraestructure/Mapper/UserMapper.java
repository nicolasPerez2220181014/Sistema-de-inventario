package com.terra.GestionYVentas.UsersModule.Users.Infraestructure.Mapper;


import com.terra.GestionYVentas.Models.User;
import com.terra.GestionYVentas.UsersModule.States.Infraestructure.StateMapper;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import org.mapstruct.Mapper;

import java.util.Optional;

@Mapper
public abstract class UserMapper {

    public User userDTOtoUser(UserDTO user){
        return User.builder()
                .userNickName(user.getUserNickName())
                .userPassword(user.getUserPassword())
                .stateId(user.getStateId())
                .personId(user.getPersonId())
                .build();
    }

    public UserDTO userToUserDTO(User user){

        return  UserDTO.builder()
                .userNickName(user.getUserNickName())
                .userPassword(user.getUserPassword())
                .stateId(user.getStateId())
                .personId(user.getPersonId())
                .build();
    }
}
