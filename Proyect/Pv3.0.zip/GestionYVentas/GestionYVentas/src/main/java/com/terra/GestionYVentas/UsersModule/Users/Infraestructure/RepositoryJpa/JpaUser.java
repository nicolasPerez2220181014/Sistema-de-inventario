package com.terra.GestionYVentas.UsersModule.Users.Infraestructure.RepositoryJpa;

import com.terra.GestionYVentas.Models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JpaUser extends JpaRepository <User,String> {
}
