package com.terra.GestionYVentas.UsersModule.Requests.Application;

import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs.RequestPersonUserDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs.RequestPersonUserUpdateDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.Services.UpdateRequestPersonUserService;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor

public class UpdateRequestPersonUserServiceForAdmin implements UpdateRequestPersonUserService {
    @Override
    public UserDTO requestToUserDTO(UserDTO userMirror, RequestPersonUserUpdateDTO userUpdatable) {
        return new UserDTO(
                userMirror.getUserNickName(),
                userUpdatable.getUserPassword(),
                userMirror.getStateId(),
                userMirror.getPersonId()
        );
    }

    @Override
    public PersonDTO requestToPersonDTO(PersonDTO personMirror, RequestPersonUserUpdateDTO personUpdatable) {
        return new PersonDTO(
                personMirror.getPersonId(),
                personUpdatable.getPersonBirthdate(),
                personUpdatable.getPersonCellphone(),
                personMirror.getPersonCreationDate(),
                personMirror.getPersonEmail(),
                personUpdatable.getPersonIdentification(),
                personUpdatable.getPersonLastname(),
                personUpdatable.getPersonName(),
                personUpdatable.getIdentificationId(),
                personMirror.getRoleId(),
                personUpdatable.getCityId());
    }

    public UserDTO requestToUserDTOAdmin(RequestPersonUserDTO request){
        return new UserDTO(request.getUserNickName(),
                request.getUserPassword(),
                request.getStateId(),
                request.getPersonId());
    }

    public PersonDTO requestToPersonDTOAdmin(RequestPersonUserDTO request) {
        return new PersonDTO(request.getPersonId(),
                request.getPersonBirthdate(),
                request.getPersonCellphone(),
                request.getPersonCreationDate(),
                request.getPersonEmail(),
                request.getPersonIdentification(),
                request.getPersonLastname(),
                request.getPersonName(),
                request.getIdentificationId(),
                request.getRoleId(),
                request.getCityId());
    }


    }









