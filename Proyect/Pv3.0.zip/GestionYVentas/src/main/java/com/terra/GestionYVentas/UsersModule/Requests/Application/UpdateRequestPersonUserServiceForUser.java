package com.terra.GestionYVentas.UsersModule.Requests.Application;

import com.terra.GestionYVentas.Models.User;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs.RequestPersonUserUpdateDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.Services.UpdateRequestPersonUserService;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Primary
@Service
@AllArgsConstructor
public class UpdateRequestPersonUserServiceForUser implements UpdateRequestPersonUserService {
    @Override
    public UserDTO requestToUserDTO(UserDTO userMirror, RequestPersonUserUpdateDTO userUpdatable) {
        return new UserDTO(
                userMirror.getUserNickName(),
                userUpdatable.getUserPassword(),
                userMirror.getStateId(),
                userMirror.getPersonId()
        );
    }
    @Override
    public PersonDTO requestToPersonDTO(PersonDTO personMirror, RequestPersonUserUpdateDTO personUpdatable) {
        return new PersonDTO(
                personMirror.getPersonId(),
                personUpdatable.getPersonBirthdate(),
                personUpdatable.getPersonCellphone(),
                personMirror.getPersonCreationDate(),
                personMirror.getPersonEmail(),
                personUpdatable.getPersonIdentification(),
                personUpdatable.getPersonLastname(),
                personUpdatable.getPersonName(),
                personUpdatable.getIdentificationId(),
                personMirror.getRoleId(),
                personUpdatable.getCityId());
    }
}
