package com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.util.Date;

@Builder
@AllArgsConstructor
@Getter
public class RequestPersonUserDTO {

    //USER
    private String userNickName;
    private String userPassword;
    private Integer stateId;
    private Integer userPersonId;
    //PERSON
    private Integer personId;
    private Date personBirthdate;
    private String personCellphone;
    private Date personCreationDate;
    private String personEmail;
    private String personIdentification;
    private String personLastname;
    private String personName;
    //PersonRelations
    private Integer identificationId;
    private Integer roleId;
    private Integer cityId;
}
