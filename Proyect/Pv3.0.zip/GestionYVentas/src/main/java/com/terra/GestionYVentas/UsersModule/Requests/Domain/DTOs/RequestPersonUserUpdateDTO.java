package com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.util.Date;
@Builder
@Getter
@AllArgsConstructor
public class RequestPersonUserUpdateDTO {

    //USER

    private String userPassword;


    //PERSON

    private Date personBirthdate;
    private String personCellphone;


    private String personIdentification;
    private String personLastname;
    private String personName;
    //PersonRelations
    private Integer identificationId;

    private Integer cityId;





}
