package com.terra.GestionYVentas.UsersModule.Requests.Domain.Services;

import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs.RequestPersonUserUpdateDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;

public interface UpdateRequestPersonUserService {

    UserDTO requestToUserDTO(UserDTO userMirror, RequestPersonUserUpdateDTO userUpdatable);

    PersonDTO requestToPersonDTO(PersonDTO personMirror, RequestPersonUserUpdateDTO personUpdatable);

}
