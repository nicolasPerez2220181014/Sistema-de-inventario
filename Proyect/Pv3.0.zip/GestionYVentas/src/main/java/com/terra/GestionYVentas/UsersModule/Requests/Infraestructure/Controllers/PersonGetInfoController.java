package com.terra.GestionYVentas.UsersModule.Requests.Infraestructure.Controllers;


import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SavePersonService;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SearchPersonService;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs.RequestPersonUserDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Infraestructure.UserPersonMapper;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SearchUserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@AllArgsConstructor
@RestController
@RequestMapping("/Api/v1/UserInformation")
public class PersonGetInfoController {

    private final SavePersonService savePersonService;
    private final SearchPersonService searchPersonService;
    private final SearchUserService searchUserService;
    private final UserPersonMapper userPersonMapper;

    @GetMapping ("/{id}")
    public ResponseEntity<RequestPersonUserDTO> SearchPersonInfo(@PathVariable("id") String id ){
        HttpStatus status = HttpStatus.NO_CONTENT;
        Integer loc = -1;

        Optional<UserDTO> searchedUser = searchUserService.SearchUser(id);
        RequestPersonUserDTO ans = null;
        if (!searchedUser.isEmpty()){
            status= HttpStatus.FOUND;
            Optional <PersonDTO> searchedPerson= searchPersonService.searchPerson(searchedUser.get().getPersonId());
            ans =  userPersonMapper.UserPersonToRequestPersonUserDTO(searchedUser.get(), searchedPerson.get() );
        }
        return new ResponseEntity(ans, status);
    }

}
