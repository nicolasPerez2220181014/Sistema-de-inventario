package com.terra.GestionYVentas.UsersModule.Requests.Infraestructure.Controllers;

import com.terra.GestionYVentas.UsersModule.Persons.Application.SavePersonServiceImpl;
import com.terra.GestionYVentas.UsersModule.Persons.Application.SearchPersonServiceImpl;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Repository.PersonSearchRepository;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SavePersonService;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SearchPersonService;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs.RequestPersonUserDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs.RequestPersonUserUpdateDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.Services.UpdateRequestPersonUserService;
import com.terra.GestionYVentas.UsersModule.Users.Application.SaveImpl.UserSaveServiceNormal;
import com.terra.GestionYVentas.UsersModule.Users.Application.UserSearchServiceImpl;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SaveUserService;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SearchUserService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@AllArgsConstructor
@RequestMapping("/Api/v1/UpdatePersonInfoAdmin")
public class PersonUpdateInfoAdminController {

    @Autowired
    @Qualifier ("updateRequestPersonUserServiceForAdmin")
    private final UpdateRequestPersonUserService updateRequestPersonUserService;

    private final SearchUserService searchUserService;
    private final SearchPersonService searchPersonService;
    private final SavePersonService savePersonService;
    private final SaveUserService saveUserService;

    @PutMapping({"/{id}"})
    public ResponseEntity<HttpHeaders> addUser(@RequestBody RequestPersonUserDTO request, @PathVariable("id") String id) {


        Optional<UserDTO> userS = searchUserService.SearchUser(id);
        Optional<PersonDTO> personS = searchPersonService.searchPerson(userS.get().getPersonId());

        //PersonDTO person = updateRequestPersonUserService.(personS.get(),request);
        //UserDTO user = updateRequestPersonUserService.requestToUserDTO(userS.get(),request);

        //savePersonService.savePerson(person);
        //saveUserService.saveUser(user);



        HttpHeaders headers = new HttpHeaders();
        headers.add("Location", "/Api/v1/UpdatePersonInfo/" + "UPDATE");
        return new ResponseEntity(headers, HttpStatus.OK);


    }



}
