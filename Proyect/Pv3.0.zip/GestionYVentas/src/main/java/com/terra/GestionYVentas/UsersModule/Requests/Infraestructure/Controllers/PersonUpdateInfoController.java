package com.terra.GestionYVentas.UsersModule.Requests.Infraestructure.Controllers;


import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SavePersonService;
import com.terra.GestionYVentas.UsersModule.Persons.Domain.Services.SearchPersonService;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs.RequestPersonUserUpdateDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.Services.UpdateRequestPersonUserService;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SaveUserService;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SearchUserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@AllArgsConstructor
@RestController
@RequestMapping("/Api/v1/UpdatePersonInfo")
public class PersonUpdateInfoController {

    private UpdateRequestPersonUserService updateRequestPersonUserService;
    private SearchPersonService searchPersonService;
    private SearchUserService searchUserService;
    private SaveUserService saveUserService;
    private SavePersonService savePersonService;

    @PutMapping({"/{id}"})
    public ResponseEntity<HttpHeaders> addUser(@RequestBody RequestPersonUserUpdateDTO requestPersonUserUpdateDTO, @PathVariable("id") String id) {

        Optional<UserDTO> userS = searchUserService.SearchUser(id);
        Optional<PersonDTO> personS = searchPersonService.searchPerson(userS.get().getPersonId());
        PersonDTO person = updateRequestPersonUserService.requestToPersonDTO(personS.get(),requestPersonUserUpdateDTO);
        UserDTO user = updateRequestPersonUserService.requestToUserDTO(userS.get(),requestPersonUserUpdateDTO);
        savePersonService.savePerson(person);
        saveUserService.saveUser(user);



        HttpHeaders headers = new HttpHeaders();
        headers.add("Location", "/Api/v1/UpdatePersonInfo/" + "UPDATE");
        return new ResponseEntity(headers, HttpStatus.OK);


    }



}
