package com.terra.GestionYVentas.UsersModule.Requests.Infraestructure;

import com.terra.GestionYVentas.UsersModule.Persons.Domain.Model.PersonDTO;
import com.terra.GestionYVentas.UsersModule.Requests.Domain.DTOs.RequestPersonUserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import org.mapstruct.Mapper;

@Mapper
public abstract class UserPersonMapper {

    public UserDTO RequestPersonUserDTOToUserDTO(RequestPersonUserDTO user){
        return  UserDTO.builder()
                .userNickName(user.getUserNickName())
                .userPassword(user.getUserPassword())
                .personId(user.getUserPersonId())
                .stateId(user.getStateId())
                .build();
    }

    public PersonDTO RequestPersonUserDTOtoPersonDTO(RequestPersonUserDTO person){
        return PersonDTO.builder()
                .personId(person.getPersonId())
                .personName(person.getPersonName())
                .personLastname(person.getPersonLastname())
                .personEmail(person.getPersonEmail())
                .personCellphone(person.getPersonCellphone())
                .personCreationDate(person.getPersonCreationDate())
                .personIdentification(person.getPersonIdentification())
                .roleId(person.getRoleId())
                .identificationId(person.getIdentificationId())
                .cityId(person.getCityId())
                .build();
    }

    public RequestPersonUserDTO UserPersonToRequestPersonUserDTO (UserDTO user, PersonDTO person){
        return RequestPersonUserDTO.builder()
                .userNickName(user.getUserNickName())
                .userPassword(user.getUserPassword())
                .userPersonId(user.getPersonId())
                .stateId(user.getStateId())

                .personId(person.getPersonId())
                .personName(person.getPersonName())
                .personLastname(person.getPersonName())
                .personEmail(person.getPersonEmail())
                .personCellphone(person.getPersonCellphone())
                .personCreationDate(person.getPersonCreationDate())
                .personIdentification(person.getPersonIdentification())
                .roleId(person.getRoleId())
                .identificationId(person.getIdentificationId())
                .cityId(person.getCityId())
                .build();
    }


}
