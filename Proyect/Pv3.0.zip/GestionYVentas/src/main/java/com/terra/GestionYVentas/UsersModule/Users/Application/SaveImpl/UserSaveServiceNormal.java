package com.terra.GestionYVentas.UsersModule.Users.Application.SaveImpl;

import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Repository.UserSaveRepository;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SaveUserService;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Primary
@AllArgsConstructor
@Service
public class UserSaveServiceNormal implements SaveUserService {

    private final UserSaveRepository us;

    @Override
    public String saveUser(UserDTO user) {
        return us.saveService(user);
    }



}
