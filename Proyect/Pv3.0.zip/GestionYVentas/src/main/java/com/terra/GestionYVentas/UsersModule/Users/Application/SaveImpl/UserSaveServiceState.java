package com.terra.GestionYVentas.UsersModule.Users.Application.SaveImpl;


import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Repository.UserSaveRepository;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SaveUserService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;


@AllArgsConstructor
@Service
public class UserSaveServiceState implements SaveUserService {

    private final UserSaveRepository us;

    @Override
    public String saveUser(UserDTO userMirror) {
        UserDTO user = new UserDTO(userMirror.getUserNickName(),userMirror.getUserPassword(),2,userMirror.getPersonId());
        return us.saveService(user);
    }

}
