package com.terra.GestionYVentas.UsersModule.Users.Infraestructure.Controllers;


import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SaveUserService;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SearchUserService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@AllArgsConstructor
@RestController
@RequestMapping("/Api/v1/DeleteAccount")
public class UserDeleteController {


    @Autowired
    @Qualifier ("userSaveServiceState")
    private final SaveUserService saveUserService;

    private final SearchUserService  searchUserService;



    @PutMapping ("{id}")
    public ResponseEntity<HttpHeaders> changeState(@PathVariable("id") String id){

        HttpStatus status = HttpStatus.NOT_FOUND;

        Optional<UserDTO> searchedUser = searchUserService.SearchUser(id);
        if (!searchedUser.isEmpty() ){
            status= HttpStatus.OK;
            saveUserService.saveUser(searchedUser.get());
        }
        HttpHeaders headers = new HttpHeaders();
        headers.add("Result", "/Api/v1/User/DELETED");

        return new ResponseEntity(headers, status);
    }
}
