package com.terra.GestionYVentas.ProductModule.Controller.ProductPK;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.terra.GestionYVentas.ProductModule.Domain.ProductRepository;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;


@Controller
@RequestMapping(path ="/product")
public class ProductController {

		

	    @Autowired
	    private ProductRepository productRepository;


	    @GetMapping(value = "/add")
	    public String agregarProducto(Model model) {
	        model.addAttribute("product", new Product());
	        return "product/add_product";
	    }

	    @GetMapping(value = "/select")
	    public String mostrarProductos(Model model) {
	        model.addAttribute("product", productRepository.findAll());
	        return "product/see_product";
	    }

	    @PostMapping(value = "/delete")
	    public String eliminarProducto(@ModelAttribute Product product, RedirectAttributes redirectAttrs) {
	        redirectAttrs
	                .addFlashAttribute("mensaje", "Eliminado correctamente")
	                .addFlashAttribute("clase", "warning");
	        productRepository.deleteById(product.getProductSerial());
	        return "redirect:/product/select";
	    }

	    // Se colocó el parámetro ID para eso de los errores, ya sé el id se puede recuperar
	    // a través del modelo, pero lo que yo quiero es que se vea la misma URL para regresar la vista con
	    // los errores en lugar de hacer un redirect, ya que si hago un redirect, no se muestran los errores del formulario
	    // y por eso regreso mejor la vista 
	    
	    @PostMapping(value = "/update/{id}")
	    public String actualizarProducto(@ModelAttribute @Validated Product product, BindingResult bindingResult, RedirectAttributes redirectAttrs) {
	        if (bindingResult.hasErrors()) {
	            if (product.getProductSerial() != null) {
	                return "product/update_product";
	            }
	            return "redirect:/products/select";
	        }
	        String posibleProductoExistente = productRepository.findFirstByName(product.getProductName());

	        if (posibleProductoExistente != null && !posibleProductoExistente.equals(product.getProductName())) {
	            redirectAttrs
	                    .addFlashAttribute("mensaje", "Ya existe un producto con ese código")
	                    .addFlashAttribute("clase", "warning");
	            return "redirect:/products/add";
	        }
	        productRepository.save(product);
	        redirectAttrs
	                .addFlashAttribute("mensaje", "Editado correctamente")
	                .addFlashAttribute("clase", "success");
	        return "redirect:/products/select";
	    }

	    @GetMapping(value = "/update/{id}")
	    public String mostrarFormularioEditar(@PathVariable int id, Model model) {
	        model.addAttribute("product", productRepository.findById(id));
	        return "products/update_producto";
	    }

	    @PostMapping(value = "/add")
	    public String guardarProducto(@ModelAttribute @Validated Product product, BindingResult bindingResult, RedirectAttributes redirectAttrs) {
	        if (bindingResult.hasErrors()) {
	            return "products/add_producto";
	        }
	        if (productRepository.findFirstByName(product.getProductName()) != null) {
	            redirectAttrs
	                    .addFlashAttribute("mensaje", "Ya existe un producto con ese código")
	                    .addFlashAttribute("clase", "warning");
	            return "redirect:/products/add";
	        }
	        productRepository.save(product);
	        redirectAttrs
	                .addFlashAttribute("mensaje", "Agregado correctamente")
	                .addFlashAttribute("clase", "success");
	        return "redirect:/products/add";
	    }

	
}
