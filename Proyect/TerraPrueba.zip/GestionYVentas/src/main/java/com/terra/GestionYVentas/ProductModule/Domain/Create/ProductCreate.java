package com.terra.GestionYVentas.ProductModule.Domain.Create;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;


public interface ProductCreate {

   void create(Product product);	
		
}
