package com.terra.GestionYVentas.ProductModule.Domain.Delete;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;

public interface ProductDelete {

	   void delete(Product product);	
	
}
