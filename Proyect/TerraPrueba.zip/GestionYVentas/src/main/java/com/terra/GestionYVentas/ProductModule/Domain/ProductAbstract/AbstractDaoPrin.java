package com.terra.GestionYVentas.ProductModule.Domain.ProductAbstract;



import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.NoSuchElementException;

import javax.persistence.Column;
import javax.persistence.Id;

import com.terra.GestionYVentas.ProductModule.Infrastructure.IDto;
import com.terra.GestionYVentas.conexion.Conexion;

import antlr.collections.List;

public class AbstractDaoPrin<T extends IDao> implements IDao
{

	

    private static Integer productSerial;

	private static String productDescription;

	private static Integer productImage;

	private static String productName;

	private static BigDecimal productSellPrice;

	private static Integer productStock;

    protected Conexion con;

    private Class<T> entityClass;

    public AbstractDaoPrin(Class<T> entityClass)
    {
        con = Conexion.getInstance();
        this.entityClass = entityClass;
    }

    @Override
    public boolean insert(IDto dto)
    {
        return con.executeUpdate(dto.insert()) ;
    }

    @Override
    public boolean update(IDto dto)
    {
        return con.executeUpdate(dto.update()) ;
    }


    @Override
    public boolean delete(IDto dto)
    {
        return con.executeUpdate(dto.delete()) ;
    }

    //retorna el objeto de la llave primaria que le estamos pasando por parametro
    //entityclass es un objeto que almacena la clase
    public IDto getById(IDto dto)
    {
        T temp = newObject();

        ResultSet rs = con.executeQuery(dto.findByid());

        try
        {
            while (rs.next())
            {
            	temp = dataForObject(rs, temp);
            }
        }

        catch (SQLException e)
        {

        }

        return (IDto) temp;
    }


    private T dataForObject(ResultSet rs, T newObject)
    {
        try
        {
            ResultSetMetaData metaData = rs.getMetaData();

            for (int i = 1; i <= metaData.getColumnCount(); i++)
            {
                String nameMethodSet = getNameSet(metaData.getColumnName(i)); // id setId(Int)
                Method methodToExecute = entityClass.getMethod(nameMethodSet, Class.forName(metaData.getColumnClassName(i)));
                ((java.lang.reflect.Method) methodToExecute).invoke(newObject, rs.getObject(i));
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return newObject;
    }


    private String setFirstLetterToUpperCase(String word)
    {
        return Character.toUpperCase(word.charAt(0)) + word.substring(1);
    }

    private String getNameSet(String columnName)
    {
        while(columnName.indexOf("_") > 0)
        {
            int pos = columnName.indexOf("_");
            columnName = columnName.substring(0,pos) + setFirstLetterToUpperCase(columnName.substring(pos +1));
        }
        return "set"+setFirstLetterToUpperCase(columnName.substring(0));
    }

    //getAll hacer, es el getById con 3 o mas lines, hay que delcarar un linkedlist de tipo idto y lo crean,
    //y tambien tienen que declarar el newobject, y ejecutamos el getall y el result set va a traer varias filas,




public void productsValuesSerial(int serial)
{
    ResultSet rs = con.executeQuery(((IDto) newObject()).findAll());

    try {
        while (rs.next())

        {
            productSerial = rs.getInt(1);
            productName = rs.getString(2);
            productSellPrice = rs.getBigDecimal(3);
            productStock = rs.getInt(4);
            productImage = rs.getInt(5);
            productDescription = rs.getString(6);
            

            if (productSerial == serial)
            {
                break;
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
    }


    System.out.println("Id = "+ productSerial +" Name = "+ productName + " Price = "+ productSellPrice + " Stocks = "+ productStock + " Images number = "+ productImage + " Description = "+ productDescription );
}

    public void productsValuesName(String name)
    {
        ResultSet rs = con.executeQuery(((IDto) newObject()).findAll());

        try {
            while (rs.next())

            {
            	productSerial = rs.getInt(1);
                productName = rs.getString(2);
                productSellPrice = rs.getBigDecimal(3);
                productStock = rs.getInt(4);
                productImage = rs.getInt(5);
                productDescription = rs.getString(6);

                if (String.valueOf(productName).equals(name))
                {
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


        System.out.println("Id = "+ productSerial +" Name = "+ productName + " Price = "+ productSellPrice + " Stocks = "+ productStock + " Images number = "+ productImage + " Description = "+ productDescription );
    }

    public List getAll()
    {
        ResultSet rs = con.executeQuery(newObject().findAll());

        List getAllList = new List()
        {
			
			@Override
			public int length() {
				// TODO Auto-generated method stub
				return 0;
			}
			
			@Override
			public boolean includes(Object arg0) {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public Enumeration elements() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Object elementAt(int arg0) throws NoSuchElementException {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public void append(Object arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void add(Object arg0) {
				// TODO Auto-generated method stub
				
			}
		};

        try
        {
            while (rs.next())
            {

                T newObject = newObject();

                newObject = dataForObject(rs, newObject);

                getAllList.add(newObject);

            }

        }

        catch (SQLException e)
        {

        }

        return getAllList;
    }


    public T newObject()
    {
        T newObject = null;

        try
        {
            newObject = entityClass.getConstructor().newInstance();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return newObject;
    }

    protected java.lang.reflect.Field[] getFields()
    {
        return entityClass.getFields();
    }

	@Override
	public boolean inser(IDto idto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
