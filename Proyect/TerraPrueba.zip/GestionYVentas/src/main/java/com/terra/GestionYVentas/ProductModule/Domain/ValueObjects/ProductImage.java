package com.terra.GestionYVentas.ProductModule.Domain.ValueObjects;

import org.hibernate.query.criteria.internal.ValueHandlerFactory.BigIntegerValueHandler;

import com.terra.GestionYVentas.ProductModule.Share.Domain.ValueObject.StringValueObject;

public class ProductImage extends StringValueObject{

	public ProductImage(String value){
		super(value);
	}
	
}
