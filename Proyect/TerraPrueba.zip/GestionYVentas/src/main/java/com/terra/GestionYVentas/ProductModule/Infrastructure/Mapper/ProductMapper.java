package com.terra.GestionYVentas.ProductModule.Infrastructure.Mapper;

import org.mapstruct.Mapper;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;
import com.terra.GestionYVentas.ProductModule.Domain.Create.ProductRequest;

import lombok.Builder;

@Mapper
@Builder
public abstract class ProductMapper {

	public Product requesToProduct(ProductRequest request)
	{
	return Product.;
	}
	
}
