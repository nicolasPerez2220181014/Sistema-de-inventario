package com.terra.GestionYVentas.ProductModule.Share.Domain.ValueObject;

import java.util.Objects;
import java.util.UUID;

public abstract class Identifier {

    protected final String value;

    public Identifier(String value) {
        ensureValidUuid(value);
        this.value = value;
    }

    private void ensureValidUuid(String value) throws IllegalArgumentException{
        UUID.fromString(value);
    }

    public String value(){
        return value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Identifier that = (Identifier) o;
        return Objects.equals(value, that.value);
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }
}