package com.terra.GestionYVentas.ProductTest.Product.Application;

import java.util.UUID;

import org.junit.jupiter.api.Test;

public class CreateProductTest extends RequestTest{

	@Test
    public void create() throws Exception {

        assertRequestWithBody("PUT",
                              "/api/v1/product/" + UUID.randomUUID().toString(),
                              "{\"name\":\"The best course\",\"duration\":\"2 month\"}",
                              201);
	
}

}