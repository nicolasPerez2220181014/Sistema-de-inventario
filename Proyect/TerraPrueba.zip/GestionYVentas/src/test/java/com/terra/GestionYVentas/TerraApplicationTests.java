package com.terra.GestionYVentas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TerraApplicationTests {

	@Test
	void contextLoads() {
	}

}
