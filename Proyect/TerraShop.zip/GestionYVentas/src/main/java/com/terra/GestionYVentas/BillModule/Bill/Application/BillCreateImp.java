package com.terra.GestionYVentas.BillModule.Bill.Application;

import com.terra.GestionYVentas.BillModule.Bill.Domain.Repository.BillCreateRepository;

public class BillCreateImp implements BillCreateRepository {
	
    private final BillCreateRepository billCreate = null;

	@Override
	public String saveService(BillRequest bill) {
		// TODO Auto-generated method stub
		return billCreate.saveService(bill);
	}

}
