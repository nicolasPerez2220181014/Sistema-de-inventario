package com.terra.GestionYVentas.BillModule.Bill.Domain.Model;

import java.util.Date;

import com.terra.GestionYVentas.Models.Person;
import com.terra.GestionYVentas.Models.States;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.PayForm;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Shipping;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@AllArgsConstructor
@Getter
public class BillRequest {
	
	private Integer billId;
	
	private Date billDate;
	
	private PayForm payForm;
	
	private Person person;
	
	private Shipping shipping;
	
	private States state;

}
