package com.terra.GestionYVentas.BillModule.Bill.Domain.Repository;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;

public interface BillCreateRepository {

	String saveService(BillRequest bill);

	
}
