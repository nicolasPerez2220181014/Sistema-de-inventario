package com.terra.GestionYVentas.BillModule.Bill.Domain.Repository;

import java.util.Optional;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;

public interface BillSearchRepository {

    Optional<BillRequest> search(Integer bill);

}
