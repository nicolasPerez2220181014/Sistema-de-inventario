package com.terra.GestionYVentas.BillModule.Bill.Domain.Services.Delete;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.ProductModule.Application.ProductRequest;

public interface BillDelete {
	
	String delete(BillRequest product);	

}
