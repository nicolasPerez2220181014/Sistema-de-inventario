package com.terra.GestionYVentas.BillModule.Bill.Domain.Services.Search;

import java.util.Optional;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.ProductModule.Application.ProductRequest;

public interface BillSearch {
	
    Optional<BillRequest> SearchBillService(Integer id);

}
