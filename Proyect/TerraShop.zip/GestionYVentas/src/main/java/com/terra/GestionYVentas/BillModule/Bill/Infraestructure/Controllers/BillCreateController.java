package com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Controllers;

import java.util.Optional;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.BillModule.Bill.Domain.Services.Create.BillCreate;
import com.terra.GestionYVentas.BillModule.Bill.Domain.Services.Search.BillSearch;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("/Api/v1/Bill")
public class BillCreateController {

	private final BillCreate billCreate = null;
	
    private final BillSearch billSearch = null;

    @PutMapping("/{id}")
    public ResponseEntity<HttpHeaders> addUser(@RequestBody BillRequest bills, @PathVariable("id") Integer id){

            Optional<BillRequest> temp =billSearch.SearchBillService(id);
            String loc = "BAD_BILL_ID";
            if (!temp.isEmpty()){
                loc =  billCreate.create(bills);
            }
            billCreate.create(bills);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Location", "/Api/v1/Bill/"+loc);
            return new ResponseEntity(headers, HttpStatus.CREATED);
    }
    
}
