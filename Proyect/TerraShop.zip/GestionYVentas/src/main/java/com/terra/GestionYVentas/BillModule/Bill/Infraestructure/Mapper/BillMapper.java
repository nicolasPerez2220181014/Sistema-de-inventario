package com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Mapper;

import java.util.Optional;

import org.mapstruct.Mapper;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Bill;

@Mapper
public class BillMapper {

	private BillMapper billMapper;

    public Bill billDTOtobill(BillRequest bill){
    	
    	/**
    	 
        return Bill.builder()
                .billId(bill.getBillId())
                .billDate(bill.getBillDate())
                .payForm(bill.getPayForm())
                .person(bill.getPerson())
                .shipping(bill.getShipping())
                .state(bill.getState()).build();
                
        **/
    	
    	return null;
    }

    public Optional<BillRequest> billToBillDTO(Bill bill){

    	/**
    	  
        Optional<BillRequest> res = Optional.of(BillRequest.builder()
                .billId(bill.getBillId())
                .billDate(bill.getBillDate())
                .payForm(bill.getPayForm())
                .person(bill.getPerson())
                .shipping(bill.getShipping())
                .state(bill.getState()).build();

        return  res;
        
        **/
    	
        return null;
    }
	
}
