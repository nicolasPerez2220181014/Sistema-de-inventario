package com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Repository;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Mapper.BillMapper;

public class BillCreateRepositoryImpl {

	private final JpaBill jpaBill = null;
    private final BillMapper billMapper = null;

    public Integer saveService(BillRequest bill) {
        return jpaBill.save(billMapper.billDTOtobill(bill)).getBillId();
    }

	
}
