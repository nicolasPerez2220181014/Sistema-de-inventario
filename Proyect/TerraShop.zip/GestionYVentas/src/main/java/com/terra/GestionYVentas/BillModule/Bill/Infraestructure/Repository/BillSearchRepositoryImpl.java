package com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Repository;

import java.util.Optional;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.BillModule.Bill.Domain.Repository.BillSearchRepository;
import com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Mapper.BillMapper;

public class BillSearchRepositoryImpl implements BillSearchRepository {

	private final JpaBill jpaBill = null;
    private final BillMapper billMapper = null;
    

	@Override
	public Optional<BillRequest> search(Integer bill) {
		// TODO Auto-generated method stub
		return billMapper.billToBillDTO(jpaBill.findById(bill).get());
	}

	
	
}
