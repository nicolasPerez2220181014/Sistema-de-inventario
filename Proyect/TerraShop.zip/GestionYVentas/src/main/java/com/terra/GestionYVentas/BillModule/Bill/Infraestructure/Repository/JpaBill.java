package com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Bill;

public interface JpaBill extends JpaRepository<Bill, Integer> {

}
