package com.terra.GestionYVentas.BillModule.BillProducts.Application;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.BillModule.Bill.Domain.Repository.BillCreateRepository;
import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Model.BillProductsRequest;
import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Repository.BillProductsCreateRepository;

public class BillProductsCreateImpl implements BillProductsCreateRepository {
	
	private final BillProductsCreateRepository billCreate = null;

	@Override
	public String saveService(BillProductsRequest bill) {
		// TODO Auto-generated method stub
		return billCreate.saveService(bill);
	}
}
