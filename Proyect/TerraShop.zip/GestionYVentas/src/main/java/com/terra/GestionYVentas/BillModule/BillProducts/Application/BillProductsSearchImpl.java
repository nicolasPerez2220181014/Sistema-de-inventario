package com.terra.GestionYVentas.BillModule.BillProducts.Application;

import java.util.Optional;

import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Model.BillProductsRequest;
import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Repository.BillProductsSearchRepository;
import com.terra.GestionYVentas.BillModule.BillProducts.Infraestructure.Controllers.BillProductsSearchControllers;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Repository.UserSearchRepository;

public class BillProductsSearchImpl implements BillProductsSearchRepository {
	
	private final BillProductsSearchRepository searchUser = null;

   
	@Override
	public Optional<BillProductsRequest> search(Integer bill) {
		// TODO Auto-generated method stub
		return searchUser.search(bill);
	}
}
