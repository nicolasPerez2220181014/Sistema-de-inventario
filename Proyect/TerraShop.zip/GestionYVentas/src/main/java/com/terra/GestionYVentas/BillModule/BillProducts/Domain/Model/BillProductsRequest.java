package com.terra.GestionYVentas.BillModule.BillProducts.Domain.Model;

import java.math.BigDecimal;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Bill;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.BillsProductPK;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;

public class BillProductsRequest {

	private BillsProductPK id;

	private BigDecimal discount;

	private BigDecimal tax;

	private BigDecimal total;

	private Integer units;
	
	private Bill bill;

	private Product product;

}
