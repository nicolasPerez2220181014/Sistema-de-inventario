package com.terra.GestionYVentas.BillModule.BillProducts.Domain.Repository;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Model.BillProductsRequest;

public interface BillProductsCreateRepository {
	String saveService(BillProductsRequest bill);

}
