package com.terra.GestionYVentas.BillModule.BillProducts.Domain.Repository;

import java.util.Optional;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Model.BillProductsRequest;

public interface BillProductsSearchRepository {
	
    Optional<BillProductsRequest> search(Integer bill);

}
