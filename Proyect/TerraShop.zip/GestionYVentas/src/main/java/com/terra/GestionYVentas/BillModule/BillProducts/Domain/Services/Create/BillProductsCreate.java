package com.terra.GestionYVentas.BillModule.BillProducts.Domain.Services.Create;

import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Model.BillProductsRequest;
import com.terra.GestionYVentas.ProductModule.Application.ProductRequest;

public interface BillProductsCreate {
	   String create(BillProductsRequest product);	

}
