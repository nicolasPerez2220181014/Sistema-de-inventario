package com.terra.GestionYVentas.BillModule.BillProducts.Domain.Services.Search;

import java.util.Optional;

import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Model.BillProductsRequest;
import com.terra.GestionYVentas.ProductModule.Application.ProductRequest;

public interface BillProductsSearch {
    Optional<BillProductsRequest> SearchUserService(Integer id);

}
