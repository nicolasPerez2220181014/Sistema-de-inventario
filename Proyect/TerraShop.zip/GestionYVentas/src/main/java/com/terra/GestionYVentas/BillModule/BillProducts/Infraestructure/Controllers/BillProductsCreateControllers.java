package com.terra.GestionYVentas.BillModule.BillProducts.Infraestructure.Controllers;

import java.util.Optional;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.BillModule.Bill.Domain.Services.Create.BillCreate;
import com.terra.GestionYVentas.BillModule.Bill.Domain.Services.Search.BillSearch;
import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Model.BillProductsRequest;
import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Services.Create.BillProductsCreate;
import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Services.Search.BillProductsSearch;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("/Api/v1/BillProduct")
public class BillProductsCreateControllers {

	private final BillProductsCreate billProductsCreate = null;
	
    private final BillProductsSearch billProductsSearch = null;

    @PutMapping("/{id}")
    public ResponseEntity<HttpHeaders> addUser(@RequestBody BillProductsRequest bills, @PathVariable("id") Integer id){

            Optional<BillProductsRequest> temp =billProductsSearch.SearchUserService(id);
            String loc = "BAD_BILL_ID";
            if (!temp.isEmpty()){
                loc =  billProductsCreate.create(bills);
            }
            billProductsCreate.create(bills);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Location", "/Api/v1/BillProducts/"+loc);
            return new ResponseEntity(headers, HttpStatus.CREATED);
    }
	
}
