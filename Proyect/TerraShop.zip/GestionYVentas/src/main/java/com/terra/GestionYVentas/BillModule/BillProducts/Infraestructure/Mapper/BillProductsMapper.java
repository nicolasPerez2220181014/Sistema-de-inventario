package com.terra.GestionYVentas.BillModule.BillProducts.Infraestructure.Mapper;

import java.util.Optional;

import org.mapstruct.Mapper;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Mapper.BillMapper;
import com.terra.GestionYVentas.BillModule.BillProducts.Domain.Model.BillProductsRequest;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Bill;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.BillsProduct;

@Mapper
public class BillProductsMapper {
	
	private BillProductsMapper billMapper;

    public BillsProduct billDTOtobill(BillRequest bill){
    	
    	/**
    	 
        return Bill.builder()
                .id(bill.getId())
                .discount(bill.getDiscount())
                .tax(bill.getTax())
                .total(bill.getTotal())
                .units(bill.getUnits())
                .bill(bill.getBill())                
                .product(bill.getProduct()).build();
                
        **/
    	
    	return null;
    }

    public Optional<BillProductsRequest> billToBillDTO(BillsProduct bill){

    	/**
    	  
        Optional<BillProductsRequest> res = Optional.of(BillProductsRequest.builder()
                .id(bill.getId())
                .discount(bill.getDiscount())
                .tax(bill.getTax())
                .total(bill.getTotal())
                .units(bill.getUnits())
                .bill(bill.getBill())                
                .product(bill.getProduct()).build();

        return  res;
        
        **/
    	
        return null;
    }
}
