package com.terra.GestionYVentas.BillModule.BillProducts.Infraestructure.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.BillsProduct;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;

public interface JpaBillProduct extends JpaRepository<BillsProduct, Integer>{

}
