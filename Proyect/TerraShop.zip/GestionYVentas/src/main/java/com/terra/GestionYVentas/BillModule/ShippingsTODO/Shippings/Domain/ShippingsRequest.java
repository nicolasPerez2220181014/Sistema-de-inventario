package com.terra.GestionYVentas.BillModule.ShippingsTODO.Shippings.Domain;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.ShippingName;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@AllArgsConstructor
@Getter
public class ShippingsRequest {

	private Integer shippingGuide;
	
	private ShippingName shippingName;

}
