package com.terra.GestionYVentas.BillModule.ShippingsTODO.Shippings.Infraestructure;

import org.mapstruct.Mapper;

import com.terra.GestionYVentas.BillModule.ShippingsTODO.Shippings.Domain.ShippingsRequest;
import com.terra.GestionYVentas.Objetives.Domain.ObjetivesRequest;

@Mapper
public class ShippingMapper {
	
	public ShippingsRequest ShippingToMapper(ShippingsRequest objetives){
        //return ShippingsRequest.builder().typeId(objetives.getTypeId()).shippingName(objetives.getShippingName()).build();
		return null;
    }
}
