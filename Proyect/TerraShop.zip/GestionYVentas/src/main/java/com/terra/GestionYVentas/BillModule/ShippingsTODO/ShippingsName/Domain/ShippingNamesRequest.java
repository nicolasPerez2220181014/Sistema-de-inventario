package com.terra.GestionYVentas.BillModule.ShippingsTODO.ShippingsName.Domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@AllArgsConstructor
@Getter
public class ShippingNamesRequest {
	
	private Integer shippingId;
	
	private String shippingName;

}
