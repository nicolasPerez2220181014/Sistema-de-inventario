package com.terra.GestionYVentas.BillModule.ShippingsTODO.ShippingsName.Infraestructure;

import org.mapstruct.Mapper;

import com.terra.GestionYVentas.BillModule.ShippingsTODO.ShippingsName.Domain.ShippingNamesRequest;
import com.terra.GestionYVentas.Objetives.Domain.ObjetivesRequest;

@Mapper
public class ShippingsNameMapper {
	
	public ShippingNamesRequest ShippingNameToMapper(ObjetivesRequest objetives){
        //return ShippingNamesRequest.builder().shippingId(objetives.getsShippingId()).shippingName(objetives.getShippingName()).build();
		return null;
    }
}
