package com.terra.GestionYVentas.Categories.Domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@AllArgsConstructor
@Getter
public class CategoriesRequest {

	private Integer categoryId;
	
	private String categoryName;
	
}
