package com.terra.GestionYVentas.Categories.Infraestructure;

import org.mapstruct.Mapper;

import com.terra.GestionYVentas.Categories.Domain.CategoriesRequest;

@Mapper
public class CategoriesMapper {
	
	public CategoriesRequest categoriesToMapper(CategoriesRequest categories){
        //return CategoriesRequest.builder().categoryId(categories.getCategoryId()).categoryName(categories.getCategoryName()).build();
		return null;
    }
}
