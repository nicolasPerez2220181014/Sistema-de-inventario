package com.terra.GestionYVentas.Objetives.Domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@AllArgsConstructor
@Getter
public class ObjetivesRequest {
	
	private Integer typeId;
	
	private String typeName;

}
