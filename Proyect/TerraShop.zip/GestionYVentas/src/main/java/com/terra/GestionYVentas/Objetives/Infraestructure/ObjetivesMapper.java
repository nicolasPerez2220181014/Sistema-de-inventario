package com.terra.GestionYVentas.Objetives.Infraestructure;

import org.mapstruct.Mapper;

import com.terra.GestionYVentas.Categories.Domain.CategoriesRequest;
import com.terra.GestionYVentas.Objetives.Domain.ObjetivesRequest;

@Mapper
public class ObjetivesMapper {

	public ObjetivesRequest ObjetivesToMapper(ObjetivesRequest objetives){
        //return ObjetivesRequest.builder().shippingGuide(objetives.getShippingGuide()).typeName(objetives.getTypeName()).build();
		return null;
    }

}
