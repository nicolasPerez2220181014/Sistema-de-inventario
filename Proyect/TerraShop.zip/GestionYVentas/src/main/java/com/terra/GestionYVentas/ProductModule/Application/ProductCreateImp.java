package com.terra.GestionYVentas.ProductModule.Application;

import org.springframework.data.jpa.repository.JpaRepository;

import com.terra.GestionYVentas.ProductModule.Domain.ProductRepository;
import com.terra.GestionYVentas.ProductModule.Domain.Create.ProductCreate;
import com.terra.GestionYVentas.ProductModule.Infrastructure.Mapper.ProductMapper;

public class ProductCreateImp implements ProductCreate{

	private final ProductCreate create = null;

  
	@Override
	public String create(ProductRequest product) {
		// TODO Auto-generated method stub
		return create.create(product);
	}
	
}
