package com.terra.GestionYVentas.ProductModule.Application;

import java.math.BigDecimal;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Category;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Objetive;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Supplier;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@AllArgsConstructor
@Getter
@Builder
public class ProductRequest {
	
    private Integer productSerial;

	private String productDescription;

	private Integer productImage;

	private String productName;

	private BigDecimal productSellPrice;

	private Integer productStock;
	
	private Category category;

	private Objetive objetive;
	
	private Supplier supplier;
	
	
}
