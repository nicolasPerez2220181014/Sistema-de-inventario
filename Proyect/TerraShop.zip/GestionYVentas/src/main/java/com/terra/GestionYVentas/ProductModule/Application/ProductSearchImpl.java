package com.terra.GestionYVentas.ProductModule.Application;

import java.util.Optional;

import com.terra.GestionYVentas.BillModule.Bill.Application.BillRequest;
import com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Mapper.BillMapper;
import com.terra.GestionYVentas.BillModule.Bill.Infraestructure.Repository.JpaBill;
import com.terra.GestionYVentas.ProductModule.Domain.Search.ProductSearch;

public class ProductSearchImpl implements ProductSearch{
	
	private final ProductSearch product= null;
    
	@Override
	public Optional<ProductRequest> SearchUserService(Integer bill) {
		// TODO Auto-generated method stub
		return product.SearchUserService(bill);
	}

}
