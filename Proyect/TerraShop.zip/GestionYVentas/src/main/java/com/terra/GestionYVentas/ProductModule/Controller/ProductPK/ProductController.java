package com.terra.GestionYVentas.ProductModule.Controller.ProductPK;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.terra.GestionYVentas.ProductModule.Application.ProductRequest;
import com.terra.GestionYVentas.ProductModule.Domain.ProductRepository;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;
import com.terra.GestionYVentas.ProductModule.Domain.Create.ProductCreate;
import com.terra.GestionYVentas.ProductModule.Domain.Delete.ProductDelete;
import com.terra.GestionYVentas.ProductModule.Domain.Search.ProductSearch;

import lombok.AllArgsConstructor;


@AllArgsConstructor
@RestController
@RequestMapping("/Api/v1/ProductModule")
public class ProductController {

		
	private final ProductCreate createProduct = null;
	private final ProductSearch searchProduct = null;

    

    @PutMapping("/{id}")
    public ResponseEntity<HttpHeaders> addUser(@RequestBody ProductRequest product, @PathVariable("id") Integer id){

            Optional<ProductRequest> temp =searchProduct.SearchUserService(id);
            String loc = "BAD_PRODUCT_SERIAL";
            if (!temp.isEmpty()){
                loc =  createProduct.create(product);
            }
            createProduct.create(product);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Location", "/Api/v1/ProductModule/"+loc);
            return new ResponseEntity(headers, HttpStatus.CREATED);
            
    }
	   
	
}
