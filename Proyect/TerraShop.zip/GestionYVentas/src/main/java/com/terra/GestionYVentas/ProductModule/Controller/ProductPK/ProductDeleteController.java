package com.terra.GestionYVentas.ProductModule.Controller.ProductPK;

import java.util.Optional;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.terra.GestionYVentas.ProductModule.Application.ProductRequest;
import com.terra.GestionYVentas.ProductModule.Domain.Create.ProductCreate;
import com.terra.GestionYVentas.ProductModule.Domain.Delete.ProductDelete;
import com.terra.GestionYVentas.ProductModule.Domain.Search.ProductSearch;

public class ProductDeleteController {

    private final ProductDelete deleteProduct = null;
	private final ProductSearch searchProduct = null;

    

    @PutMapping("/{id}")
    public ResponseEntity<HttpHeaders> addUser(@RequestBody ProductRequest product, @PathVariable("id") Integer id){

            Optional<ProductRequest> temp =searchProduct.SearchUserService(id);
            String loc = "BAD_USER_NAME";
            if (!temp.isEmpty()){
                loc =  deleteProduct.delete(product);
            }
            deleteProduct.delete(product);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Location", "/Api/v1/ProductModule/"+loc);
            return new ResponseEntity(headers, HttpStatus.ACCEPTED);
            
    }
	
}
