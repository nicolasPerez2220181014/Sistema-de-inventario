package com.terra.GestionYVentas.ProductModule.Domain.BasicModels;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the bills_products database table.
 * 
 */
@Embeddable
public class BillsProductPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="fk_product_serial", insertable=false, updatable=false)
	private Integer fkProductSerial;

	@Column(name="fk_bills_id", insertable=false, updatable=false)
	private Integer fkBillsId;

	public BillsProductPK() {
	}
	public Integer getFkProductSerial() {
		return this.fkProductSerial;
	}
	public void setFkProductSerial(Integer fkProductSerial) {
		this.fkProductSerial = fkProductSerial;
	}
	public Integer getFkBillsId() {
		return this.fkBillsId;
	}
	public void setFkBillsId(Integer fkBillsId) {
		this.fkBillsId = fkBillsId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BillsProductPK)) {
			return false;
		}
		BillsProductPK castOther = (BillsProductPK)other;
		return 
			this.fkProductSerial.equals(castOther.fkProductSerial)
			&& this.fkBillsId.equals(castOther.fkBillsId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.fkProductSerial.hashCode();
		hash = hash * prime + this.fkBillsId.hashCode();
		
		return hash;
	}
}