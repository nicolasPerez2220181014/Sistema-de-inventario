package com.terra.GestionYVentas.ProductModule.Domain.Create;

import com.terra.GestionYVentas.ProductModule.Application.ProductRequest;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;


public interface ProductCreate {

   String create(ProductRequest product);	
		
}
