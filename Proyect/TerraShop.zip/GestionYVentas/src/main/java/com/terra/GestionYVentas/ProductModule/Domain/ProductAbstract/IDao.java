package com.terra.GestionYVentas.ProductModule.Domain.ProductAbstract;

import com.terra.GestionYVentas.ProductModule.Infrastructure.IDto;

import antlr.collections.List;

public interface IDao {

	public boolean inser(IDto idto);
	public boolean update(IDto idto);
	public boolean delete(IDto idto);
	public IDto getById(IDto idto);
	public List getAll();
	boolean insert(IDto dto);
	public String findAll();


	
}
