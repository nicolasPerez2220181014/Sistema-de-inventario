package com.terra.GestionYVentas.ProductModule.Domain;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;


@Repository
public class ProductRepository extends Product{

	
	//void save(Product product);

	
	private static final long serialVersionUID = 1L;
	
	@SuppressWarnings("products")
	private HashMap<String, Product> products;
	
	
	public void save(Product product) {
		
	products = null;
		
	}

	public String findAll() {
		// TODO Auto-generated method stub
		return "SELECT * FROM Product;";

	}

	public String deleteById(Integer id) 
	{
		// TODO Auto-generated method stub
		
		return "DELETE FROM Product WHERE product_serial = " + id + ";";
		
	}

	public String findFirstByName(String name) 
	{
		// TODO Auto-generated method stub
		
		return "SELECT * FROM Product WHERE product_name = " + name + ";";
	
	}

	public String findById(int id) 
	{
		// TODO Auto-generated method stub
		return "SELECT * FROM Product WHERE product_serial = " + id +";";
	}
	
	public String update(Integer id, String name, BigDecimal price, Date date, Integer stock, Integer image) {
			
		return "update Product set product_name =" + name +
             ", product_sell_price='" + price +
             "', Product_expires_date='" + date+
             "', product_stock="+ stock+
             ", product_image="+ image+
             "where id_cliente =" + id +";";	
	
	}


	
	
}
