package com.terra.GestionYVentas.ProductModule.Domain.Search;

import java.util.Optional;

import com.terra.GestionYVentas.ProductModule.Application.ProductRequest;

public interface ProductSearch {
	
    Optional<ProductRequest> SearchUserService(Integer id);
}
