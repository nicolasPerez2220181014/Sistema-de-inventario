package com.terra.GestionYVentas.ProductModule.Domain.ValueObjects;

import com.terra.GestionYVentas.ProductModule.Share.Domain.ValueObject.Identifier;
import com.terra.GestionYVentas.ProductModule.Share.Domain.ValueObject.StringValueObject;

public class ProducSellPrice extends Identifier{
	

		public ProducSellPrice(String value){
			super(value);
		}

}
