package com.terra.GestionYVentas.ProductModule.Domain.ValueObjects;

import com.terra.GestionYVentas.ProductModule.Share.Domain.ValueObject.StringValueObject;

public class ProductName extends StringValueObject{
	
	public ProductName(String value){
		super(value);
	}
}
