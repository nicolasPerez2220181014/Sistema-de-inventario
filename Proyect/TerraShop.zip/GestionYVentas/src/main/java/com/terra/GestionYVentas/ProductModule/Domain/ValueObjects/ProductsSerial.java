package com.terra.GestionYVentas.ProductModule.Domain.ValueObjects;

import com.terra.GestionYVentas.ProductModule.Share.Domain.ValueObject.StringValueObject;

public class ProductsSerial extends StringValueObject{

	public ProductsSerial(String value){
		super(value);
	}
	
}
