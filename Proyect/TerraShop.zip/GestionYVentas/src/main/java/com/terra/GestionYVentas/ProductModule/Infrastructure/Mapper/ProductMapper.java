package com.terra.GestionYVentas.ProductModule.Infrastructure.Mapper;

import org.mapstruct.Mapper;

import com.sun.el.stream.Optional;
import com.terra.GestionYVentas.ProductModule.Application.ProductRequest;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Category;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Objetive;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;
import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Supplier;

import lombok.Builder;


@Mapper
public abstract class ProductMapper {

    private Integer productStock;
	
	private Category category;

	private Objetive objetive;
	
	private Supplier supplier;
	
	
	public Product requesToProduct(ProductRequest request)
	{
		/**
	return Product.builder()
            .productSerial(request.getProductSerial())
            .productDescription(request.getProductDescription())
            .productImage(request.getProductImage())
            .productName(request.getProductName())
            .productSellPrice(request.getProductSellPrice())
            .productStock(request.getProductStock())
            .category(request.getCategory()).build();
            .objetive(request.getObjetive()).build();
            .supplier(request.getSupplier()).build();
       **/
		
		return null;
	}
	
	public java.util.Optional<ProductRequest> userToUserDTO(Product request){

		/**
        java.util.Optional<ProductRequest> res = Optional.of(ProductRequest.builder()
        		.productSerial(request.getProductSerial())
                .productDescription(request.getProductDescription())
                .productImage(request.getProductImage())
                .productName(request.getProductName())
                .productSellPrice(request.getProductSellPrice())
                .productStock(request.getProductStock())
                .category(request.getCategory()).build();
                .objetive(request.getObjetive()).build();
                .supplier(request.getSupplier()).build());


        return  res;
         
         **/
		
		return null;
        
    }
	
}
