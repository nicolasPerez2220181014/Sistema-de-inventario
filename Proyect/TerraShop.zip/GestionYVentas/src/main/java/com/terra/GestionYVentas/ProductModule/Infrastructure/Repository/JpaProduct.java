package com.terra.GestionYVentas.ProductModule.Infrastructure.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.terra.GestionYVentas.ProductModule.Domain.BasicModels.Product;

public interface JpaProduct extends JpaRepository<Product, Integer>{

}
