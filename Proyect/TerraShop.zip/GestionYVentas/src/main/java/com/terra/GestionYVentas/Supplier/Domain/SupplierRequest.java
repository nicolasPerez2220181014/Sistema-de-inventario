package com.terra.GestionYVentas.Supplier.Domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@AllArgsConstructor
@Getter
public class SupplierRequest {
	
	private Integer supplierId;
	
	private String supplierName;

}
