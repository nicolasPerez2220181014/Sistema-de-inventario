package com.terra.GestionYVentas.Supplier.Infraestructure;

import org.mapstruct.Mapper;

import com.terra.GestionYVentas.Categories.Domain.CategoriesRequest;
import com.terra.GestionYVentas.Supplier.Domain.SupplierRequest;

@Mapper
public class SupplierMapper {
	
	public SupplierRequest supplierToMapper(SupplierRequest supplier){
        //return SupplierRequest.builder().supplierId(supplier.getSupplierId()).categoryName(supplier.getSupplierName()).build();
		return null;
    }
}
