package com.terra.GestionYVentas.UsersModule.States.Domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@AllArgsConstructor
@Getter
public class StateDTO {

    private Integer stateId;
    private String stateName;
}
