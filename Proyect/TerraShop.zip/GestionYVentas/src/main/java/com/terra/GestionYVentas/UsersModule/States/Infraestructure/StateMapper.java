package com.terra.GestionYVentas.UsersModule.States.Infraestructure;

import org.mapstruct.Mapper;

import com.terra.GestionYVentas.UsersModule.States.Domain.StateDTO;

@Mapper
public class StateMapper {

    public StateDTO stateToStateDTO(StateDTO state){
    
    	/**
        return StateDTO.builder().stateId(state.getStateId()).stateName(state.getStateName()).build();
        **/
        return null;
    }

}
