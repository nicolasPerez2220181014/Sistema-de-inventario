package com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@AllArgsConstructor
@Getter
public class UserDTO {
    private String userNickName;
    private String userPassword;
    private Integer state;
}
