package com.terra.GestionYVentas.UsersModule.Users.Domain.Services;

import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;

import java.util.Optional;


public interface SearchUserService {

    Optional<UserDTO> SearchUser(String id);
}
