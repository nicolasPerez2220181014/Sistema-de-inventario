package com.terra.GestionYVentas.UsersModule.Users.Infraestructure.Controllers;


import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SaveUserService;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Services.SearchUserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@AllArgsConstructor
@RestController
@RequestMapping("/Api/v1/User")
public class UserController {

    private final SearchUserService searchServ = null;
    private final SaveUserService saveServ = null;

    @PutMapping("/{id}")
    public ResponseEntity<HttpHeaders> addUser(@RequestBody UserDTO user, @PathVariable("id") String id){

            Optional<UserDTO> temp =searchServ.SearchUser(id);
            String loc = "BAD_USER_NAME";
            if (!temp.isEmpty()){
                loc =  saveServ.saveUser(user);
            }
            saveServ.saveUser(user);
            HttpHeaders headers = new HttpHeaders();
            headers.add("Location", "/Api/v1/User/"+loc);
            return new ResponseEntity(headers, HttpStatus.CREATED);
    }


}
