package com.terra.GestionYVentas.UsersModule.Users.Infraestructure.Mapper;


import com.terra.GestionYVentas.Models.User;
import com.terra.GestionYVentas.UsersModule.States.Infraestructure.StateMapper;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import org.mapstruct.Mapper;

import java.util.Optional;

@Mapper
public abstract class UserMapper {

    private StateMapper sMapper;

    public User userDTOtoUser(UserDTO user){
        /**
    	return User.builder()
                .userNickName(user.getUserNickName())
                .userPassword(user.getUserPassword())
                .idState(user.getState()).build();
        **/
    	return null;
    }

    public Optional<UserDTO> userToUserDTO(User user){

    	/**
        Optional<UserDTO> res = Optional.of(UserDTO.builder()
                .userNickName(user.getUserNickName())
                .userPassword(user.getUserPassword())
                .state(user.getIdState()).build());


        return  res;
        **/
        return null;
    }
}
