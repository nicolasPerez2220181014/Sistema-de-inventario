package com.terra.GestionYVentas.UsersModule.Users.Infraestructure.RepositoryJpa;

import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Repository.UserSaveRepository;
import com.terra.GestionYVentas.UsersModule.Users.Infraestructure.Mapper.UserMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

@AllArgsConstructor
@Repository
public class UserSaveRepositoryImpl implements UserSaveRepository {
    private final JpaUser jpaUser = null;
    private final UserMapper userMapper = null;

    @Override
    public String saveService(UserDTO user) {
        return jpaUser.save(userMapper.userDTOtoUser(user)).getUserNickName();
    }
}
