package com.terra.GestionYVentas.UsersModule.Users.Infraestructure.RepositoryJpa;

import com.terra.GestionYVentas.UsersModule.Users.Domain.Model.DTO.UserDTO;
import com.terra.GestionYVentas.UsersModule.Users.Domain.Repository.UserSearchRepository;
import com.terra.GestionYVentas.UsersModule.Users.Infraestructure.Mapper.UserMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@AllArgsConstructor
@Repository
public class UserSearchRepositoryImpl implements UserSearchRepository {

    private final JpaUser jpaUser = null;
    private final UserMapper userMapper = null;

    @Override
    public Optional<UserDTO> search(String user) {
        return userMapper.userToUserDTO(jpaUser.findById(user).get());
    }
}