package com.terra.GestionYVentas.conexion;

import java.beans.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.sun.jdi.connect.spi.Connection;

public class Conexion {

	private static Conexion conexion;
	
	private java.sql.Connection con;

	public Conexion() {

		Properties properties = new Properties();
		
		try 
		{
		
			String url = "jdbc:postgresql://localHost:5431/terra";
			String user = "postgresql";
			String password = "postgresql";
			
			Class.forName("org.postgresql.Driver");
			
			con = (java.sql.Connection) DriverManager.getConnection(url, user, password);
			
			System.out.println("Conectado");
			  
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	
	}
	
	
	public static Conexion getInstance() {
		
		if(conexion == null) 
		{
			conexion = new Conexion();
			
		}
		return conexion;
		
	}
	

	public boolean executeUpdate(String update) {
		// TODO Auto-generated method stub
		
		int temp = 0;
		
		try {
			
			Statement statement = (Statement) con.createStatement();
			temp = ((java.sql.Statement) statement).executeUpdate(update);
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		
		return false;
	}



	public ResultSet executeQuery(String findAll) {
		// TODO Auto-generated method stub
		
		ResultSet result = null;
		
		try {
			
			Statement statement = (Statement) con.createStatement();
			result = ((java.sql.Statement) statement).executeQuery(findAll);
			
			
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return result;
	}
	
}
