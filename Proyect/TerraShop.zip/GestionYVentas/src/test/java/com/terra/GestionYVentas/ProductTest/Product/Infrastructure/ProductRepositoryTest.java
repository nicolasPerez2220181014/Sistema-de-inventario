package com.terra.GestionYVentas.ProductTest.Product.Infrastructure;

public class ProductRepositoryTest {

}
